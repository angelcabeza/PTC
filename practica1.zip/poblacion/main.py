#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
    Fichero que ejecuta todos los ficheros que resuelven los ejercicios de
    la práctica
"""


import R1
import R2
import R3
import R4
import R5
import R6


R1.main()
R2.main()
R3.main()
R4.main()
R5.main()
R6.main()